// loy vanich 2021 Azure IoT Hub
// MQTT Pub Sub
#include <WiFi.h>
#include <PubSubClient.h>
#include <Arduino.h>
#include <string.h>
#include "DHT.h"

#define DHTPIN 25
#define DHTTYPE DHT11 // DHT 11

int LED_BUILTIN = 2;

const char *ssid = "xxxxx";
const char *password = "xxxxxx";
const char *mqttServer = "broker.emqx.io";
const int mqttPort = 1883;
const char *mqttUser = "loy";
const char *mqttPassword = "1234";

WiFiClient espClient;
PubSubClient client(espClient);
DHT dht(DHTPIN, DHTTYPE);

void callback(char *topic, byte *message, unsigned int length)
{
  char s[length];
  memcpy(s, message, length);
  s[length] = '\0';
  Serial.print(s);
  Serial.print(" ");
  if (strcmp(s, "OFF") == 0)
    digitalWrite(LED_BUILTIN, LOW);
  if (strcmp(s, "ON") == 0)
    digitalWrite(LED_BUILTIN, HIGH);
}

void reconnect()
{
  while (!client.connected())
  {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ESP32Client"))
    {
      Serial.print("connected ");
      client.subscribe("loy/test1");
    }
    else
    {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.print(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void Send(String s)
{
  if (!client.connected())
  {
    Serial.print("Connecting to MQTT:");
    if (client.connect("ESP32Client", mqttUser, mqttPassword))
      Serial.print(" connected! ");
    else
    {
      Serial.print(" failed with state ");
      Serial.print(client.state());
      delay(2000);
    }
  }
  else
  {
    char charBuf[50];
    s.toCharArray(charBuf, 12);
    if (client.publish("loy/test1", charBuf))
      Serial.print("TX ");
    else
      Serial.print("ER ");
  }
}

void setup()
{
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  dht.begin();

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }
  Serial.println("Connected to the WiFi network");

  client.setServer(mqttServer, mqttPort);
  client.setCallback(callback);
}

void loop()
{
  if (!client.connected())
  {
    reconnect();
  }
  client.loop();
  delay(2000);

  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (isnan(h) || isnan(t))
  {
    Serial.print("DHT11 error ");
  }
  else
  {
    String s = "H";
    s.concat(h);
    s.concat("T");
    s.concat(t);
    Serial.print(s + " ");
    Send(s);
  }
}