// loy vanich 2021 Azure IoT Hub
// Azure IoT Hub get C2D message
#include <WiFi.h>
#include "Esp32MQTTClient.h"

static const char *connectionString = "HostName=loyiothub.azure-devices.net;DeviceId=loyesp32a;SharedAccessKey=ptf5yr/uxlpJsSEhyPw32M=";
const char *ssid = "xxxxxx";
const char *password = "xxxxxxx";
static bool hasIoTHub = false;

void setup()
{
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  for (int i = 0; i < 10; i++)
  {
    Serial.print(" . ");
    delay(1000);
  }
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi OK! ");

  if (!Esp32MQTTClient_Init((const uint8_t *)connectionString))
  {
    hasIoTHub = false;
    return;
  }
  else
  {
    hasIoTHub = true;
  }
}

void loop()
{
  if (hasIoTHub)
  {
    Esp32MQTTClient_Check(); // for in comming message
  }
  delay(10);
}