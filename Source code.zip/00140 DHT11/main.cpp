// loy vanich 2021 Azure IoT Hub
// Test DHT11 sensor
// install lib Adafruit Unified Sensor, 
// DHT sensor library

#include "DHT.h"

#define DHTPIN 25
#define DHTTYPE DHT11   // DHT 11

DHT dht(DHTPIN, DHTTYPE);

void setup()
{
  Serial.begin(115200);
  Serial.println("DHT11 test!");
  dht.begin();
}

void loop()
{
  delay(2500);

  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (isnan(h) || isnan(t)) {
    Serial.println(F("Failed to read from DHT sensor!"));
    return;
  }

  Serial.print("Humidity: ");
  Serial.print(h);
  Serial.print("%\tTemperature: ");
  Serial.print(t);
  Serial.print("°C\n");
}
