// loy vanich 2021 Azure IoT Hub
// MQTT Subscribe command from broker
// and turn on-off LED
#include <WiFi.h>
#include <PubSubClient.h>
# include <Arduino.h>
# include <string.h>

int LED_BUILTIN = 2;

const char *ssid = "xxxxx";
const char *password = "xxxxxx";
const char *mqttServer = "broker.emqx.io";
const int mqttPort = 1883;
const char *mqttUser = "loy";
const char *mqttPassword = "1234";

WiFiClient espClient;
PubSubClient client(espClient);

void callback(char *topic, byte *message, unsigned int length)
{
  char s[length];
  memcpy(s, message, length);
  s[length] = '\0'; 
  Serial.print(s); Serial.print(" ");
  if(strcmp(s, "OFF") == 0) digitalWrite(LED_BUILTIN, LOW);
  if(strcmp(s, "ON") == 0) digitalWrite(LED_BUILTIN, HIGH);
}

void reconnect()
{
  while (!client.connected())
  {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ESP32Client"))
    {
      Serial.print("connected ");
      client.subscribe("loy/test1");
    }
    else
    {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.print(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void setup()
{
  pinMode (LED_BUILTIN, OUTPUT);
  Serial.begin(115200);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }
  Serial.println("Connected to the WiFi network");

  client.setServer(mqttServer, mqttPort);
  client.setCallback(callback);
}

void loop()
{
  if (!client.connected())
  {
    reconnect();
  }
  Serial.print("* ");
  client.loop();
  delay(300);
}