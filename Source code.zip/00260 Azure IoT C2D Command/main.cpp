// loy vanich 2021 Azure IoT Hub
// Azure IoT Hub get C2D command
#include <WiFi.h>
#include "Esp32MQTTClient.h"
#include "DHT.h"

#define DHTPIN 25
#define DHTTYPE DHT11 // DHT 11
#define DEVICE_ID "Esp32Device"
#define MESSAGE_MAX_LEN 256

static const char *connectionString = "HostName=loyiothub.azure-devices.net;DeviceId=loyesp32a;SharedAccessKey=ptf5yr/lpJsSEhyPw32M=";
const char *ssid = "tot-issac_2.4G";
const char *password = "busaba2001";
static bool hasIoTHub = false;
static bool gotCommand = false;
DHT dht(DHTPIN, DHTTYPE);
const char *messageData = 
	"{\"deviceId\":\"%s\", \"messageId\":%d, \"Temperature\":%f, \"Humidity\":%f}";
int messageCount = 1;

void SendRequest()
{
  if (hasIoTHub)
  {
    float humidity = dht.readHumidity();
    float temperature = dht.readTemperature();
    if (isnan(humidity) || isnan(temperature))
    {
      Serial.print("DHT11 ER ");
      return;
    }
    else
    {
      char messagePayload[MESSAGE_MAX_LEN];
      snprintf(messagePayload, MESSAGE_MAX_LEN, messageData,
               DEVICE_ID, messageCount++, temperature, humidity);
      Serial.println(messagePayload);
      EVENT_INSTANCE *message = Esp32MQTTClient_Event_Generate(messagePayload, MESSAGE);
      Esp32MQTTClient_SendEventInstance(message);
      Serial.println("- - - - - - - - - - -");
    }
  }
  gotCommand = false;
}

void MessageCallback(const char *payLoad, int size)
{
  char s[size];
  memcpy(s, payLoad, size);
  s[size] = '\0';
  Serial.print(s);
  Serial.print(" ");
  if (strcmp(s, "Read") == 0)
    gotCommand = true;
}

void setup()
{
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  dht.begin();

  for (int i = 0; i < 10; i++)
  {
    Serial.print(" . ");
    delay(1000);
  }

  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi OK! ");

  if (!Esp32MQTTClient_Init((const uint8_t *)connectionString))
  {
    hasIoTHub = false;
    return;
  }
  else
  {
    Esp32MQTTClient_SetMessageCallback(MessageCallback);
    hasIoTHub = true;
  }
}

void loop()
{
  if (hasIoTHub)
  {
    Esp32MQTTClient_Check(); // for in comming message
  }
  if(gotCommand) SendRequest();
  delay(100);
}