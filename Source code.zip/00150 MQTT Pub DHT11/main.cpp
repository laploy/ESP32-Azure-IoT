// loy vanich 2021 Azure IoT Hub
// Publish DHT11 data to QMTT broker

#include "DHT.h"
#include <WiFi.h>
#include <PubSubClient.h>

#define DHTPIN 25
#define DHTTYPE DHT11 // DHT 11

const char *ssid = "xxxx";
const char *password = "xxxxx";
const char *mqttServer = "broker.emqx.io";
const int mqttPort = 1883;
const char *mqttUser = "loy";
const char *mqttPassword = "1234";

WiFiClient espClient;
PubSubClient client(espClient);
DHT dht(DHTPIN, DHTTYPE);

void setup()
{
  Serial.begin(115200);
  Serial.println("Test sending DHT11 data to MQTT Broker");
  dht.begin();
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }
  Serial.println("Connected to the WiFi network");
  client.setServer(mqttServer, mqttPort);
}

void Send(String s)
{
  if (!client.connected())
  {
    Serial.print("Connecting to MQTT:");
    if (client.connect("ESP32Client", mqttUser, mqttPassword))
      Serial.print(" connected! ");
    else
    {
      Serial.print(" failed with state ");
      Serial.print(client.state());
      delay(2000);
    }
  }
  else
  {
    char charBuf[50];
    s.toCharArray(charBuf, 13) ;
    if (client.publish("loy/test1", charBuf))
      Serial.print("TX ");
    else
      Serial.print("ER ");
  }
}

void loop()
{
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (isnan(h) || isnan(t))
  {
    Serial.print("DHT11 error ");
    return;
  }

  String s = "H"; s.concat(h);
  s.concat("T"); s.concat(t);
  Serial.print(s + " ");
  Send(s);
  delay(3000);
}
