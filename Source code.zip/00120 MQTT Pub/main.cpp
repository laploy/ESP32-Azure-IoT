// loy vanich 2021 Azure IoT Hub
// MQTT publish message to a broker
// install lib PubSubClient
// https://www.emqx.io/mqtt/public-mqtt5-broker
#include <WiFi.h>
#include <PubSubClient.h>

const char *ssid = "xxx";
const char *password = "xxxx";
const char *mqttServer = "broker.emqx.io";
const int mqttPort = 1883;
const char *mqttUser = "loy";
const char *mqttPassword = "1234";
byte count = 49; // asc for "1"

WiFiClient espClient;
PubSubClient client(espClient);

void setup()
{
  Serial.begin(115200);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }
  Serial.println("Connected to the WiFi network");

  client.setServer(mqttServer, mqttPort);
}

char c[] = "Hello ";

void loop()
{
  if (!client.connected())
  {
    Serial.print("Connecting to MQTT:");
    if (client.connect("ESP32Client", mqttUser, mqttPassword))
      Serial.print(" connected! ");
    else
    {
      Serial.print(" failed with state ");
      Serial.print(client.state());
      delay(2000);
    }
  }
  else
  {
    c[5] = count;
    if (count > 56)
      count = 48;
    if (client.publish("loy/test1", c))
    {
      Serial.print(c);
      Serial.print(" ");
      count++;
    }
    else
      Serial.print("ER ");
  }

  Serial.print("* ");
  delay(3000);
}