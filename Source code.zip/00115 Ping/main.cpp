// loy vanich 2021 Azure IoT Hub
// ping website
// install ilb ESP32Ping
#include <WiFi.h>
#include <ESP32Ping.h>

const char *ssid = "xxxx";
const char *password = "xxx";
WiFiClient espClient;

void setup()
{
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }
  Serial.println("Connected to the WiFi network");
  if (!Ping.ping("www.google.com", 3))
  {
    Serial.println("Ping failed");
    return;
  }
  Serial.println("Ping succesful.");
}

void loop()
{
  Serial.print("OK ");
  delay(1500);
}