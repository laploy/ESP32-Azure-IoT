// loy vanich 2021 Azure IoT Hub
// Azure IoT Hub send D2C DHT11 data
#include <WiFi.h>
#include "Esp32MQTTClient.h"
#include "DHT.h"

#define DHTPIN 25
#define DHTTYPE DHT11 // DHT 11

static const char *connectionString = "HostName=loyiothub.azure-devices.net;DeviceId=loyesp32a;SharedAccessKey=ptf5yr/uxlpJsSEhyPw32M=";
const char *ssid = "xxxxxx";
const char *password = "xxxx";
static bool hasIoTHub = false;
DHT dht(DHTPIN, DHTTYPE);

void send()
{
  if (hasIoTHub)
  {
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    if (isnan(h) || isnan(t))
    {
      Serial.print("DHT11 ER ");
      return;
    }
    String s = "H";
    s.concat(h);
    s.concat("T");
    s.concat(t);
    char c[50];
    s.toCharArray(c, 13);
    if (Esp32MQTTClient_SendEvent(c))
      delay(9000);
  }
}

void setup()
{
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  dht.begin();
  for (int i = 0; i < 10; i++)
  {
    Serial.print(" . ");
    delay(1000);
  }
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi OK! ");
  if (!Esp32MQTTClient_Init((const uint8_t *)connectionString))
  {
    hasIoTHub = false;
    return;
  }
  else
  {
    hasIoTHub = true;
  }
}

void loop()
{
  Serial.println("- - - - - - - - - - -");
  send();
  delay(9000);
}