// loy vanich 2021 Azure IoT Hub
// Blinky
# include <Arduino.h>

int LED_BUILTIN = 2;

void setup()
{
  Serial.begin(115200);
  pinMode (LED_BUILTIN, OUTPUT);
}

void loop()
{
  Serial.print("OK ");
  digitalWrite(LED_BUILTIN, HIGH);
  delay(100);
  digitalWrite(LED_BUILTIN, LOW);
  delay(1100);
}