// loy vanich 2021 Azure IoT Hub
// Azure IoT Hub send D2C DHT11 data
#include <WiFi.h>
#include "Esp32MQTTClient.h"
#include "DHT.h"

#define DHTPIN 25
#define DHTTYPE DHT11 // DHT 11
#define INTERVAL 40000
#define DEVICE_ID "Esp32Device"
#define MESSAGE_MAX_LEN 256

static const char *connectionString = "HostName=loyiothub.azure-devices.net;DeviceId=loyesp32a;SharedAccessKey=ptf5yr/sSEhyPw32M=";
const char *ssid = "tot-issac_2.4G";
const char *password = "busaba2001";
static bool hasIoTHub = false;
DHT dht(DHTPIN, DHTTYPE);
const char *messageData = 
	"{\"deviceId\":\"%s\", \"messageId\":%d, \"Temperature\":%f, \"Humidity\":%f}";
int messageCount = 1;
static bool messageSending = true;
static uint64_t send_interval_ms;

void setup()
{
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  dht.begin();
  for (int i = 0; i < 10; i++)
  {
    Serial.print(" . ");
    delay(1000);
  }
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi OK! ");

  if (!Esp32MQTTClient_Init((const uint8_t *)connectionString))
  {
    hasIoTHub = false;
    return;
  }
  else
  {
    hasIoTHub = true;
    send_interval_ms = millis();
  }
}

void loop()
{
  if (hasIoTHub)
  {
    if (messageSending &&
        (int)(millis() - send_interval_ms) >= INTERVAL)
    {
      float humidity = dht.readHumidity();
      float temperature = dht.readTemperature();
      if (isnan(humidity) || isnan(temperature))
      {
        Serial.print("DHT11 ER ");
        return;
      }
      else
      {
        char messagePayload[MESSAGE_MAX_LEN];
        snprintf(messagePayload, MESSAGE_MAX_LEN, messageData,
                 DEVICE_ID, messageCount++, temperature, humidity);
        Serial.println(messagePayload);
        EVENT_INSTANCE *message = Esp32MQTTClient_Event_Generate(messagePayload, MESSAGE);
        Esp32MQTTClient_Event_AddProp(message, "temperatureAlert", "true");
        Esp32MQTTClient_SendEventInstance(message);
        send_interval_ms = millis();
        Serial.println("- - - - - - - - - - -");
      }
    }
  }
  delay(10);
}